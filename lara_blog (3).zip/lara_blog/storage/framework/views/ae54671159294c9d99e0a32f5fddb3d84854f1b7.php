
<?php $__env->startSection('dashboard'); ?>

<div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12">
                   <!-- BEGIN THEME CUSTOMIZER-->
                   <div id="theme-change" class="hidden-phone">
                       <i class="icon-cogs"></i>
                        <span class="settings">
                            <span class="text">Theme Color:</span>
                            <span class="colors">
                                <span class="color-default" data-style="default"></span>
                                <span class="color-green" data-style="green"></span>
                                <span class="color-gray" data-style="gray"></span>
                                <span class="color-purple" data-style="purple"></span>
                                <span class="color-red" data-style="red"></span>
                            </span>
                        </span>
                   </div>
                   <!-- END THEME CUSTOMIZER-->
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Basic Table
                   </h3>
                  
        
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->

            <div id="page-wraper">
               
                <div class="row-fluid">
                    <div class="span12">
                        <!-- BEGIN BASIC PORTLET-->
                        <div class="widget orange">
                            <div class="widget-title">
                                <h4><i class="icon-reorder"></i> Advanced Table</h4>
                            <span class="tools">
                                <a href="javascript:;" class="icon-chevron-down"></a>
                                <a href="javascript:;" class="icon-remove"></a>
                            </span>
                            </div>
                            <div class="widget-body">
                                <table class="table table-striped table-bordered table-advance table-hover">
                                    <thead>
                                    <tr>
                                        <th><i class="icon-bullhorn"></i> Category ID</th>
                                        <th class="hidden-phone"><i class="icon-question-sign"></i> Category Name</th>
                                        <th><i class="icon-bookmark"></i> Category Description</th>
                                        <th><i class=" icon-edit"></i> Status</th>
                                        <th>Action</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody> 
                                        <?php
                                            $id=1;
                                        ?>
                                        <?php $__currentLoopData = $all_category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <tr>
                                        <td><?php echo e($id); ?></td>
                                        <td class="hidden-phone"><?php echo e($all_cat->category_name); ?></td>
                                        <td><?php echo e($all_cat->category_description); ?></td>
 
                                            <?php if($all_cat->publication_status == 1): ?>
                                                <td><span class="label label-success label-mini">Publish</span></td>
                                            <?php else: ?>
                                                <td><span class="label label-important label-mini">Unpublish</span></td>
                                            <?php endif; ?>
                                        <td>
                                            <button class="btn btn-success"><i class="icon-ok"></i></button>

                                            <a class="btn btn-primary" href="<?php echo e(url('/edit_category/'.$all_cat->category_id)); ?>"><i class="icon-pencil"></i></a>
                                            <a class="btn btn-danger" href="<?php echo e(url('/delete_category/'.$all_cat->category_id)); ?>" onclick="return chkdelete()"><i class="icon-trash"></i></a>
                                           
                                            
                                        </td>
                                    </tr>
                                    <?php
                                        $id++;
                                    ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- END BASIC PORTLET-->
                    </div>
                </div>

            </div>

            <!-- END PAGE CONTENT-->         
         </div>

                <?php $__env->stopSection(); ?>


                <img src="Thai ">


<?php echo $__env->make('backend/back_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara_blog\resources\views/backend/all_category.blade.php ENDPATH**/ ?>