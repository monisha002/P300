<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>Metro Lab</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport" />
   <meta content="" name="description" />
   <meta content="Mosaddek" name="author" />
   <link href="<?php echo e(asset('public/backasset/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/assets/bootstrap/css/bootstrap-responsive.min.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/assets/bootstrap/css/bootstrap-fileupload.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/css/style.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/css/style-responsive.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/css/style-default.css')); ?>" rel="stylesheet" id="style_color" />
   <link href="<?php echo e(asset('public/backasset/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css')); ?>" rel="stylesheet" />
   <link href="<?php echo e(asset('public/backasset/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css')); ?>" rel="stylesheet" type="text/css" media="screen"/>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
   <!-- BEGIN HEADER -->
   <div id="header" class="navbar navbar-inverse navbar-fixed-top">
       <!-- BEGIN TOP NAVIGATION BAR -->
       <div class="navbar-inner">
           <div class="container-fluid">
               <!--BEGIN SIDEBAR TOGGLE-->
               <div class="sidebar-toggle-box hidden-phone">
                   <div class="icon-reorder"></div>
               </div>
               <!--END SIDEBAR TOGGLE-->
               <!-- BEGIN LOGO -->
               <a class="brand" href="<?php echo e(url('dashboard')); ?>">
                   <h5 style="color: white;
                   font-size: 25px;
                   margin-top: 0px;
                   font-weight: 800;">Fit Health BD</h5>

               </a>
               <!-- END LOGO -->
               <!-- BEGIN RESPONSIVE MENU TOGGLER -->
               
               <!-- END RESPONSIVE MENU TOGGLER -->
               
               <!-- END  NOTIFICATION -->
               <div class="top-nav ">
                   <ul class="nav pull-right top-menu" >
                       <!-- BEGIN SUPPORT -->
                       
                       <!-- END SUPPORT -->
                       <!-- BEGIN USER LOGIN DROPDOWN -->
                       <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                               <img src="img/avatar1_small.jpg" alt="">
                              
                               <span class="username">Super Admin</span>
                               <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu extended logout">
                               
                               <li><a href="<?php echo e(route('logout')); ?>"><i class="icon-key"></i> Log Out</a></li>
                           </ul>
                       </li>
                       <!-- END USER LOGIN DROPDOWN -->
                   </ul>
                   <!-- END TOP NAVIGATION MENU -->
               </div>
           </div>
       </div>
       <!-- END TOP NAVIGATION BAR -->
   </div>
   <!-- END HEADER -->
   <!-- BEGIN CONTAINER -->
   <div id="container" class="row-fluid">
      <!-- BEGIN SIDEBAR -->
      <div class="sidebar-scroll">

       <?php echo $__env->yieldContent('sidebar'); ?>
</div>

      <!-- END SIDEBAR -->
      <!-- BEGIN PAGE -->
      <div id="main-content">
         <!-- BEGIN PAGE CONTAINER-->
        <?php echo $__env->yieldContent('dashboard'); ?>
         <!-- END PAGE CONTAINER-->
       </div>

      <!-- END PAGE -->
   </div>
   <!-- END CONTAINER -->

   <!-- BEGIN FOOTER -->
   <div id="footer">
       2013 &copy; Metro Lab Dashboard.
   </div>
   <!-- END FOOTER -->

   <!-- BEGIN JAVASCRIPTS -->
   <!-- Load javascripts at bottom, this will reduce page load time -->
   <script src="<?php echo e(asset('public/backasset/js/jquery-1.8.3.min.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/js/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
   <script type="text/javascript" src="<?php echo e(asset('public/backasset/assets/jquery-slimscroll/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
   <script type="text/javascript" src="<?php echo e(asset('public/backasset/assets/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/assets/fullcalendar/fullcalendar/fullcalendar.min.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>

   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="js/excanvas.js"></script>
   <script src="js/respond.js"></script>
   <![endif]-->

   <script src="<?php echo e(asset('public/backasset/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js')); ?>" type="text/javascript"></script>
   <script src="<?php echo e(asset('public/backasset/js/jquery.sparkline.js')); ?>" type="text/javascript"></script>
   <script src="<?php echo e(asset('public/backasset/assets/chart-master/Chart.js')); ?>"></script>

   <!--common script for all pages-->
   <script src="<?php echo e(asset('public/backasset/js/common-scripts.js')); ?>"></script>

   <!--script for this page only-->

   <script src="<?php echo e(asset('public/backasset/js/easy-pie-chart.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/js/sparkline-chart.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/js/home-page-calender.js')); ?>"></script>
   <script src="<?php echo e(asset('public/backasset/js/chartjs.js')); ?>"></script>
   <script type="text/javascript">

    function chkdelete()
    {

      chk = confirm("Are you sure to delete this category");
      if(chk){
        return true;
      }else
      {
        return false;
      }


          }
   </script>

   <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
<?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/backend/back_master.blade.php ENDPATH**/ ?>