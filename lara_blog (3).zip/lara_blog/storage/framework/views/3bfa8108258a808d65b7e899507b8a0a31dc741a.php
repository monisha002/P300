<?php

 ?> 




<?php $__env->startSection('main_contant'); ?>



 <div class="row masonry-wrap">
            <div class="masonry">

            <div class="grid-sizer"></div>
            <?php $__currentLoopData = $category_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
           

                <article class="masonry__brick entry format-standard" data-aos="fade-up">
                        
                    <div class="entry__thumb">
                        <a href="single-standard.html" class="entry__thumb-link">
                            <img src="<?php echo e(asset($category_post->blog_image)); ?>" 
                                    alt="">
                        </a>
                    </div>
    
                    <div class="entry__text">
                        <div class="entry__header">
                            
                            <div class="entry__date">
                                <a href="#"><?php echo e($category_post->created_at); ?></a>
                            </div>
                            <h1 class="entry__title"><a href="<?php echo e(url('/blog_desc/'.$category_post->blog_id)); ?>"><?php echo e($category_post->blog_name); ?></a></h1>
                            
                        </div>
                        <div class="entry__excerpt">
                            <p>
                               <?php echo e($category_post->blog_short_description); ?>

                            </p>
                        </div>
                        <div class="entry__meta">
                            <span class="entry__meta-links">
                                <a href="<?php echo e(url('/category_blog/'.$category_post->category_name)); ?>"><?php echo e($category_post->category_name); ?></a> 
                                
                            </span>
                        </div>
                    </div>
    
                </article> <!-- end article -->

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div> <!-- end masonry -->
        </div> <!-- end masonry-wrap -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara_blog\resources\views/frontend/page/category_post_home_page.blade.php ENDPATH**/ ?>