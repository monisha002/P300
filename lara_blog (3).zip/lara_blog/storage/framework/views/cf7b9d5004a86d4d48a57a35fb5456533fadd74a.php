<?php
$popular_post = DB::table('blog')
    ->orderBy('hit_count', 'asc')
    ->limit(1)
    ->get();
$popular_post2 = DB::table('blog')
    ->orderBy('hit_count', 'desc')
    ->limit(2)
    ->get();
?>

<?php $__env->startSection('header'); ?>
    <div class="pageheader-content row">
        <div class="col-full">

            <div class="featured">

                <div class="featured__column featured__column--big">
                    <?php $__currentLoopData = $popular_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="entry"
                        style="background-image:url('<?php echo e(asset($row->blog_image)); ?>');">

                            <div class="entry__content">
                                <span class="entry__category"><a href="<?php echo e(url('/blog_desc/'.$row->blog_id)); ?>"><?php echo e($row->category_name); ?></a></span>

                                <h1><a href="#0" title=""><?php echo e($row->blog_name); ?>.</a></h1>

                                <div class="entry__info">
                                    <a href="#0" class="entry__profile-pic">
                                        <img class="avatar"
                                            src="<?php echo e(asset($row->blog_image)); ?>" alt="">
                                    </a>
                                    <ul class="entry__meta">
                                        <li><a href="#0"><?php echo e($row->author_name); ?></a></li>
                                        <li><?php echo e($row->created_at); ?></li>
                                    </ul>
                                </div>
                            </div> <!-- end entry__content -->

                    </div> <!-- end entry -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div> <!-- end featured__big -->

                <div class="featured__column featured__column--small">
                    <?php $__currentLoopData = $popular_post2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="entry"
                        style="background-image:url('<?php echo e(asset($row->blog_image)); ?>');">

                        <div class="entry__content">
                            <span class="entry__category"><a href="<?php echo e(url('/blog_desc/'.$row->blog_id)); ?>"><?php echo e($row->category_name); ?></a></span>

                            <h1><a href="#0" title=""><?php echo e($row->blog_name); ?>.</a></h1>

                            <div class="entry__info">
                                <a href="#0" class="entry__profile-pic">


                                    <img class="avatar" src="<?php echo e(asset($row->blog_image)); ?>"
                                        alt="">
                                </a>

                                <ul class="entry__meta">
                                    <li><a href="#0"><?php echo e($row->author_name); ?></a></li>
                                    <li><?php echo e($row->created_at); ?></li>
                                </ul>
                            </div>
                        </div> <!-- end entry__content -->

                    </div> <!-- end entry -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div> <!-- end featured__small -->
            </div> <!-- end featured -->

        </div> <!-- end col-full -->
    </div> <!-- end pageheader-content row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/frontend/page/header.blade.php ENDPATH**/ ?>