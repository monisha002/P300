<?php $__env->startSection('main_contant'); ?>
<div class="row">

            <div class="s-content__header col-full">
                <h1 class="s-content__header-title">
                    Feel Free To Contact Us.
                </h1>
            </div> <!-- end s-content__header -->



            <div class="s-content__main" style="width: 50%;">



                <h3>Say Hello.</h3>

                <form name="cForm" id="cForm" method="post" action="">
                    <fieldset>

                        <div class="form-field">
                            <input name="cName" type="text" id="cName" class="full-width" placeholder="Your Name" value="">
                        </div>

                        <div class="form-field">
                            <input name="cEmail" type="text" id="cEmail" class="full-width" placeholder="Your Email" value="">
                        </div>

                        <div class="form-field">
                            <input name="cWebsite" type="text" id="cWebsite" class="full-width" placeholder="Website"  value="">
                        </div>

                        <div class="message form-field">
                        <textarea name="cMessage" id="cMessage" class="full-width" placeholder="Your Message" ></textarea>
                        </div>

                        <button type="submit" class="submit btn btn--primary full-width">Submit</button>

                    </fieldset>
                </form> <!-- end form -->


            </div> <!-- end s-content__main -->

        </div> <!-- end row -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/frontend/page/contact_page.blade.php ENDPATH**/ ?>