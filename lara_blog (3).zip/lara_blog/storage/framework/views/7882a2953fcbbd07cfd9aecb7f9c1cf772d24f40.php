<?php
    $all_category_data = DB::table('category')
                                 ->get();

    $popular_post = DB::table('blog')
                                ->orderBy('hit_count','desc')
                                ->limit(5)
                                 ->get();

?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>Fit Health BD</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontasset/css/base.css')); ?>">
 <!--  <link rel="stylesheet" href="<?php echo e(asset('public/frontasset/css/vendor.css')); ?>">  -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontasset/css/main.css')); ?>">


    <!-- script
    ================================================== -->
    <script src="<?php echo e(asset('public/frontasset/js/modernizr.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontasset/js/pace.min.js')); ?>"></script>

    <!-- favicons
    ================================================== -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

</head>

<body id="top">

    <!-- pageheader
    ================================================== -->
    <section class="s-pageheader s-pageheader--home">

        <header class="header">
            <div class="header__content row">

                <div class="header__logo">
                    <a class="logo" href="<?php echo e(route('home')); ?>">
                        
                        <h5 style="    color: white;
                        font-family: 'librebaskerville-bold';
                        font-size: 38px;
                        margin-top: 0px;">Fit Health BD</h5>

                    </a>
                </div> <!-- end header__logo -->

                <ul class="header__social">
                    <li>
                        <a href="#0"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                    </li>
                </ul> <!-- end header__social -->
                <a class="header__toggle-menu" href="#0" title="Menu"><span>Menu</span></a>

                <nav class="header__nav-wrap">

                    <h2 class="header__nav-heading h6">Site Navigation</h2>

                    <ul class="header__nav">
                        <li class="current"><a href="<?php echo e(route('home')); ?>" title="">Home</a></li>
                        <li class="has-children">
                            <a href="#0" title="">Categories</a>
                            <ul class="sub-menu">
                            <?php $__currentLoopData = $all_category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><a href="<?php echo e(url('/category_blog/'.$all_cat->category_name)); ?>"><?php echo e($all_cat->category_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </li>
                        <li class="has-children">
                            <a href="#0" title="">Popular Blog</a>
                            <ul class="sub-menu">
                                <?php $__currentLoopData = $popular_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><a href="<?php echo e(url('/blog_desc/'.$p_post->blog_id)); ?>"><?php echo e($p_post->blog_name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <li><a href="<?php echo e(url('about')); ?>" title="">About</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>" title="">Contact</a></li>
                    </ul> <!-- end header__nav -->



                </nav> <!-- end header__nav-wrap -->

            </div> <!-- header-content -->
        </header> <!-- header -->

        <?php echo $__env->yieldContent('header'); ?>

    </section> <!-- end s-pageheader -->


    <!-- s-content
    ================================================== -->
    <section class="s-content">
        <?php echo $__env->yieldContent('main_contant'); ?>


      <!--   <div class="row">
            <div class="col-full">
                <nav class="pgn">
                    <ul>
                        <li><a class="pgn__prev" href="#0">Prev</a></li>
                        <li><a class="pgn__num" href="#0">1</a></li>
                        <li><span class="pgn__num current">2</span></li>
                        <li><a class="pgn__num" href="#0">3</a></li>
                        <li><a class="pgn__num" href="#0">4</a></li>
                        <li><a class="pgn__num" href="#0">5</a></li>
                        <li><span class="pgn__num dots">…</span></li>
                        <li><a class="pgn__num" href="#0">8</a></li>
                        <li><a class="pgn__next" href="#0">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div> -->

    </section> <!-- s-content -->


    <!-- s-extra
    ================================================== -->
    <section class="s-extra">

        <div class="row top">

            <div class="col-eight md-six tab-full popular">
                <h3>Popular Posts</h3>

                <div class="block-1-2 block-m-full popular__posts">
                    <?php $__currentLoopData = $popular_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        

                    <article class="col-block popular__post">
                        <a href="#0" class="popular__thumb">
                        <img src="<?php echo e($popular_post->blog_image); ?>" alt="">
                        </a>
                        <h5><a href="<?php echo e(url('/blog_desc/'.$popular_post->blog_id)); ?>"><?php echo e($popular_post->blog_name); ?></a></h5>
                        <section class="popular__meta">
                                <span class="popular__author"><span>By</span> <a href="#"><?php echo e($popular_post->author_name); ?></a></span>
                            <span class="popular__date"><span>on</span> <time datetime="2017-12-19"><?php echo e($popular_post->created_at); ?></time></span>
                        </section>
                    </article>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div> <!-- end popular_posts -->
            </div> <!-- end popular -->

            <div class="col-four md-six tab-full about">
                <h3>About Fit Health BD</h3>

                <p>
                    Exercising regularly, every day if possible, is the single most important thing you can do for your health. In the short term, exercise helps to control appetite, boost mood, and improve sleep. In the long term, it reduces the risk of heart disease, stroke, diabetes, dementia, depression, and many cancers.
                </p>

                <ul class="about__social">
                    <li>
                        <a href="#0"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                    </li>
                </ul> <!-- end header__social -->
            </div> <!-- end about -->

        </div> <!-- end row -->
<?php
    $cat = DB::table('blog')
    ->get();
?>
        <div class="row bottom tags-wrap">
            <div class="col-full tags">
                <h3>Category</h3>

                <div class="tagcloud">
                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <a href="<?php echo e(url('/category_blog/'.$all_post->category_name)); ?>"><?php echo e($all_post->category_name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div> <!-- end tagcloud -->
            </div> <!-- end tags -->
        </div> <!-- end tags-wrap -->

    </section> <!-- end s-extra -->


    <!-- s-footer
    ================================================== -->
    <footer class="s-footer">

        <div class="s-footer__main">
            <div class="row">

                <div class="col-two md-four mob-full s-footer__sitelinks">

                    <h4>Quick Links</h4>

                    <ul class="s-footer__linklist">
                        <li><a href="#0">Home</a></li>
                        <li><a href="#0">Blog</a></li>
                        <li><a href="#0">Styles</a></li>
                        <li><a href="#0">About</a></li>
                        <li><a href="#0">Contact</a></li>
                        <li><a href="#0">Privacy Policy</a></li>
                    </ul>

                </div> <!-- end s-footer__sitelinks -->

                <div class="col-two md-four mob-full s-footer__archives">

                    <h4>Archives</h4>

                    <ul class="s-footer__linklist">
                        <li><a href="#0">January 2018</a></li>
                        <li><a href="#0">December 2017</a></li>
                        <li><a href="#0">November 2017</a></li>
                        <li><a href="#0">October 2017</a></li>
                        <li><a href="#0">September 2017</a></li>
                        <li><a href="#0">August 2017</a></li>
                    </ul>

                </div> <!-- end s-footer__archives -->

                <div class="col-two md-four mob-full s-footer__social">

                    <h4>Social</h4>

                    <ul class="s-footer__linklist">
                        <li><a href="#0">Facebook</a></li>
                        <li><a href="#0">Instagram</a></li>
                        <li><a href="#0">Twitter</a></li>
                        <li><a href="#0">Pinterest</a></li>
                        <li><a href="#0">Google+</a></li>
                        <li><a href="#0">LinkedIn</a></li>
                    </ul>

                </div> <!-- end s-footer__social -->

                <div class="col-five md-full end s-footer__subscribe">

                    <h4>Our Newsletter</h4>

                    <p>Sit vel delectus amet officiis repudiandae est voluptatem. Tempora maxime provident nisi et fuga et enim exercitationem ipsam. Culpa consequatur occaecati.</p>

                    <div class="subscribe-form">
                        <form id="mc-form" class="group" novalidate="true">

                            <input type="email" value="" name="EMAIL" class="email" id="mc-email" placeholder="Email Address" required="">

                            <input type="submit" name="subscribe" value="Send">

                            <label for="mc-email" class="subscribe-message"></label>

                        </form>
                    </div>

                </div> <!-- end s-footer__subscribe -->

            </div>
        </div> <!-- end s-footer__main -->

        <div class="s-footer__bottom">
            <div class="row">
                <div class="col-full">
                    <div class="s-footer__copyright">
                        <span>© Copyright Fit Health BD 2021</span>
                        <span>Developed by <a href="#">Toma & Monisha</a></span>
                    </div>

                    <div class="go-top">
                        <a class="smoothscroll" title="Back to Top" href="#top"></a>
                    </div>
                </div>
            </div>
        </div> <!-- end s-footer__bottom -->

    </footer> <!-- end s-footer -->


    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader">
            <div class="line-scale">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>


    <!-- Java Script
    ================================================== -->
    <script src="<?php echo e(asset('public/frontasset/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontasset/js/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontasset/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/frontend/master.blade.php ENDPATH**/ ?>