
<?php $__env->startSection('dashboard'); ?>


<div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
               <div class="span12">
                   <!-- BEGIN THEME CUSTOMIZER-->
                   <div id="theme-change" class="hidden-phone">
                       <i class="icon-cogs"></i>
                        <span class="settings">
                            <span class="text">Theme Color:</span>
                            <span class="colors">
                                <span class="color-default" data-style="default"></span>
                                <span class="color-green" data-style="green"></span>
                                <span class="color-gray" data-style="gray"></span>
                                <span class="color-purple" data-style="purple"></span>
                                <span class="color-red" data-style="red"></span>
                            </span>
                        </span>
                   </div>
                   <!-- END THEME CUSTOMIZER-->
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                      Add Blog Post
                   </h3>
                 
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->

            <!-- BEGIN PAGE CONTENT-->
            

            <div class="row-fluid">
                <div class="span8">
                    <!-- BEGIN VALIDATION STATES-->
                    <div class="widget yellow">
                        <div class="widget-title">
                            <h4><i class="icon-reorder"></i>Add Blog Post</h4>
                            <div class="tools">
                                <a href="javascript:;" class="collapse"></a>
                                <a href="#portlet-config" data-toggle="modal" class="config"></a>
                                <a href="javascript:;" class="reload"></a>
                                <a href="javascript:;" class="remove"></a>
                            </div>
                        </div>
                        <div class="widget-body form">
                            <!-- BEGIN FORM-->

                               <?php if($errors->any()): ?>

        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="color: black"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
            
        <?php endif; ?>

        <h3 style="color: green">
          <?php
              $message = Session::get('message');
              if ($message){
                 echo $message;
              
                Session::put('message');
              }
          ?>
        </h3> 
            
        
                            <form class="cmxform form-horizontal" enctype="multipart/form-data" id="commentForm" method="post" action="<?php echo e(route('save_blog_post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="control-group ">
                                    <label for="cname" class="control-label">Name</label>
                                    <div class="controls">
                                      <input type="hidden" name="hit_count">
                                        <input class="span6 " id="cname" name="blog_name" minlength="2" type="text" required />
                                    </div>
                                </div>
                                 <div class="control-group ">
                                    <label for="cname" class="control-label">Category Name</label>
                                    <div class="controls">
                                        <select class="span6 " name="category_name">
                                          <option value="">Select Category</option>
                                          <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option value="<?php echo e($all_category->category_name); ?>"><?php echo e($all_category->category_name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                        </select>
                                    </div>
                                </div>
                                <div class="control-group ">
                                    <label for="ccomment" class="control-label">Short Description</label>
                                    <div class="controls">
                                        <textarea class="span6 " id="ccomment" name="blog_short_description" required></textarea>
                                    </div>
                                </div>
                                 <div class="control-group ">
                                    <label for="ccomment" class="control-label">Long Description</label>
                                    <div class="controls">
                                        <textarea class="span6 " id="ccomment" name="blog_long_description" required></textarea>
                                    </div>
                                </div>
                                 <div class="control-group ">
                                    <label for="cname" class="control-label">Name</label>
                                    <div class="controls">
                                        <input type="file" class="span6 " id="cname" name="blog_image" minlength="2" type="text" required />
                                    </div>
                                </div>
                                 <div class="control-group ">
                                    <label for="cname" class="control-label">Author Name</label>
                                    <div class="controls">
                                        <input class="span6 " id="cname" name="author_name" minlength="2" type="text" required />
                                    </div>
                                </div>
                                  <div class="control-group">
                                <label class="control-label">Publiation Status</label>
                                <div class="controls">
                                    <select class="span6 " data-placeholder="Choose a Category" tabindex="1" name="publication_status">
                                        <option value="">Select...</option>
                                        <option value="1">Publish</option>
                                        <option value="0">Un publish</option>
                                    </select>
                                </div>
                            </div>
                                <div class="form-actions">
                                    <button class="btn btn-success" type="submit">Save</button>
                                    <button class="btn" type="button">Cancel</button>
                                </div>


                            </form>
                            <!-- END FORM-->
                        </div>
                    </div>
                    <!-- END VALIDATION STATES-->
                </div>
            </div>

           

            <!-- END PAGE CONTENT-->

         </div>
         <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/back_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lara_blog\resources\views/backend/add_blog_form.blade.php ENDPATH**/ ?>