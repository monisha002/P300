<?php $__env->startSection('dashboard'); ?>
<?php
    $total = DB::table('blog')
    ->get();
    $cat = DB::table('category')
    ->get();
?>

 <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
               <div class="span12">
                   <!-- BEGIN THEME CUSTOMIZER-->
                   <div id="theme-change" class="hidden-phone">
                       <i class="icon-cogs"></i>
                        <span class="settings">
                            <span class="text">Theme Color:</span>
                            <span class="colors">
                                <span class="color-default" data-style="default"></span>
                                <span class="color-green" data-style="green"></span>
                                <span class="color-gray" data-style="gray"></span>
                                <span class="color-purple" data-style="purple"></span>
                                <span class="color-red" data-style="red"></span>
                            </span>
                        </span>
                   </div>
                   <!-- END THEME CUSTOMIZER-->
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                     Dashboard
                   </h3>
                   <ul class="breadcrumb">
                       <li class="active">
                          Admin Dashboard
                       </li>

                   </ul>
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
                <!--BEGIN METRO STATES-->
                <div class="metro-nav">
                    <div class="metro-nav-block nav-block-orange double">
                        <a data-original-title="" href="#">
                            <i class="icon-user"></i>
                            <div class="info">1</div>
                            <div class="status">Total User</div>
                        </a>
                    </div>
                    <div class="metro-nav-block nav-block-yellow double">
                        <a data-original-title="" href="#">
                            <i class="icon-tags"></i>
                            <div class="info"><?php echo sizeOf($total) ?></div>
                            <div class="status">Total Post</div>
                        </a>
                    </div>
                    <div class="metro-nav-block nav-block-grey double">
                        <a data-original-title="" href="#">
                            <i class="icon-comments-alt"></i>
                            <div class="info"><?php echo sizeOf($cat) ?></div>
                            <div class="status">Total Category</div>
                        </a>
                    </div>
                    
                </div>
                
                <div class="space10"></div>
                <!--END METRO STATES-->
            </div>
            

            <!-- END PAGE CONTENT-->
         </div>

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/back_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>