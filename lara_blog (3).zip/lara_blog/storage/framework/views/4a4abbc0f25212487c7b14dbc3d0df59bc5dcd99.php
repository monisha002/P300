<?php $__env->startSection('sidebar'); ?>


 <div id="sidebar" class="nav-collapse collapse">

         <!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
         <div class="navbar-inverse">
            <form class="navbar-search visible-phone">
               <input type="text" class="search-query" placeholder="Search" />
            </form>
         </div>
         <!-- END RESPONSIVE QUICK SEARCH FORM -->
         <!-- BEGIN SIDEBAR MENU -->
          <ul class="sidebar-menu">
              <li class="sub-menu active">
                  <a class="" href="<?php echo e(url('dashboard')); ?>">
                      <i class="icon-dashboard"></i>
                      <span>Dashboard</span>
                  </a>
              </li>

                <li class="sub-menu">
                  <a href="javascript:;" class="">
                      <i class="icon-tasks"></i>
                      <span>Category</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                      <li><a class="" href="<?php echo e(route('cat_form')); ?>">Add Category</a></li>
                      <li><a class="" href="<?php echo e(route('all_category')); ?>">All Category</a></li>
                  </ul>
              </li>
              <li class="sub-menu">
                  <a href="javascript:;" class="">
                      <i class="icon-book"></i>
                      <span>Blog</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub">
                      <li><a class="" href="<?php echo e(route('blog_form')); ?>">Add Blog</a></li>
                      <li><a class="" href="<?php echo e(route('all_blog_post')); ?>">All Blog List</a></li>
                  </ul>
              </li>
              
          </ul>
         <!-- END SIDEBAR MENU -->
      </div>

      <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/back_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lara_blog\resources\views/backend/sidebar.blade.php ENDPATH**/ ?>