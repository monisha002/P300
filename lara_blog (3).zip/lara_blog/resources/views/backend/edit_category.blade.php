

@extends('backend/back_master')
@section('dashboard')


<div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
               <div class="span12">
                   <!-- BEGIN THEME CUSTOMIZER-->
                   <div id="theme-change" class="hidden-phone">
                       <i class="icon-cogs"></i>
                        <span class="settings">
                            <span class="text">Theme Color:</span>
                            <span class="colors">
                                <span class="color-default" data-style="default"></span>
                                <span class="color-green" data-style="green"></span>
                                <span class="color-gray" data-style="gray"></span>
                                <span class="color-purple" data-style="purple"></span>
                                <span class="color-red" data-style="red"></span>
                            </span>
                        </span>
                   </div>
                   <!-- END THEME CUSTOMIZER-->
                  <!-- BEGIN PAGE TITLE & BREADCRUMB-->
                   <h3 class="page-title">
                      Add Category
                   </h3>
                 
                   <!-- END PAGE TITLE & BREADCRUMB-->
               </div>
            </div>
            <!-- END PAGE HEADER-->

            <!-- BEGIN PAGE CONTENT-->
            

            <div class="row-fluid">
                <div class="span8">
                    <!-- BEGIN VALIDATION STATES-->
                    <div class="widget yellow">
                        <div class="widget-title">
                            <h4><i class="icon-reorder"></i>Add Category</h4>
                            <div class="tools">
                                <a href="javascript:;" class="collapse"></a>
                                <a href="#portlet-config" data-toggle="modal" class="config"></a>
                                <a href="javascript:;" class="reload"></a>
                                <a href="javascript:;" class="remove"></a>
                            </div>
                        </div>
                        <div class="widget-body form">

       
            
        
                            <form class="cmxform form-horizontal" id="commentForm" method="post" action="{{route('update_category')}}">
                                @csrf
                                <div class="control-group ">
                                    <label for="cname" class="control-label">Category Name</label>
                                    <div class="controls">
                                        <input type="hidden" name="category_id" value="<?php echo $all_category->category_id?>">
                                        <input class="span6"id="cname" name="category_name" value="<?php echo $all_category->category_name ?>" minlength="2" type="text" required />
                                    </div>
                                </div>
                                <div class="control-group ">
                                    <label for="ccomment" class="control-label">Category Description</label>
                                    <div class="controls">
                                        <textarea class="span6 " id="ccomment" name="category_desc" required><?php echo $all_category->category_description ?></textarea>
                                    </div>
                                </div>
                                 
                                <div class="form-actions">
                                    <button class="btn btn-success" type="submit">Update</button>
                                    <button class="btn" type="button">Cancel</button>
                                </div>


                            </form>
                            <!-- END FORM-->
                        </div>
                    </div>
                    <!-- END VALIDATION STATES-->
                </div>
            </div>

           

            <!-- END PAGE CONTENT-->

         </div>
         @endsection