@extends('frontend/master')
@section('main_contant')


<div class="row">

    <div class="s-content__header col-full">
        <h1 class="s-content__header-title">
            Learn More About Us.
        </h1>
    </div> <!-- end s-content__header -->

    <div class="s-content__media col-full">
        <div class="s-content__post-thumb">
            <img src="images/thumbs/about/about-1000.jpg"
                 srcset="images/thumbs/about/about-2000.jpg 2000w,
                         images/thumbs/about/about-1000.jpg 1000w,
                         images/thumbs/about/about-500.jpg 500w"
                 sizes="(max-width: 2000px) 100vw, 2000px" alt="" >
        </div>
    </div> <!-- end s-content__media -->

    <div class="col-full s-content__main">

        <p class="lead">Eating a healthy, balanced diet is one of the most important things you can do to protect your health. In fact, up to 80% of premature heart disease and stroke can be prevented through your life choices and habits, such as eating a healthy diet and being physically active.

            A healthy diet can help lower your risk of heart disease and stroke by:

            improving your cholesterol levels
            reducing your blood pressure
            helping you manage your body weight
            controlling your blood sugar.</p>

        <p>What does a healthy, balanced diet look like?
            Canada’s Food Guide recommends eating a variety of healthy foods each day. This includes eating plant-based foods more often and choosing highly-processed or ultra-processed foods less often.
        </p>

        <p> Eating lots of vegetables and fruit

            This is one of the most important diet habits. Vegetables and fruit are packed with nutrients (antioxidants, vitamins, minerals and fibre) and help you maintain a healthy weight by keeping you full longer.
            Fill half your plate with vegetables and fruit at every meal and snack.
             </p>

        <div class="row block-1-2 block-tab-full">
            <div class="col-block">
                <h3 class="quarter-top-margin">Who We Are.</h3>
                <p> Choosing whole grain foods

                    Whole grain foods include whole grain bread and crackers, brown or wild rice, quinoa, oatmeal and hulled barley. They are prepared using the entire grain. Whole grain foods have fibre, protein and B vitamins to help you stay healthy and full longer.
                    Choose whole grain options instead of processed or refined grains like white bread and pasta.
                    Fill a quarter of your plate with whole grain foods.</p>
            </div>

            <div class="col-block">
                <h3 class="quarter-top-margin">Our Mission.</h3>
                <p>Protein foods include legumes, nuts, seeds, tofu, fortified soy beverage, fish, shellfish, eggs, poultry, lean red meats including wild game, lower fat milk, lower fat yogurts, lower fat kefir and cheeses lower in fat and sodium.
                    Protein helps build and maintain bones, muscles and skin.
                    Eat protein every day.
                    Try to eat at least two servings of fish each week, and choose plant-based foods more often.
                    Dairy products are a great source of protein. Choose lower fat, unflavoured options.</p>
            </div>

            <div class="col-block">
                <h3 class="quarter-top-margin">Our Vision.</h3>
                <p>Highly processed foods — often called ultra-processed — are foods that are changed from their original food source and have many added ingredients. During processing, often important nutrients such as vitamins, minerals and fiber are removed while salt and sugar are added.  Examples of processed food include: fast foods, hot dogs, chips, cookies, frozen pizzas, deli meats, white rice and white bread. Learn more about ultra-processed foods here.
                    Some minimally processed foods are okay. These are foods that are slightly changed in some way but contain few industrially made additives. Minimally processed foods keep almost all of their essential nutrients. Some examples are: bagged salad, frozen vegetables and fruit, eggs, milk, cheese, flour, brown rice, oil and dried herbs. We are not referring to these minimally processed foods when we are advising you not to eat processed foods.</p>
            </div>

            <div class="col-block">
                <h3 class="quarter-top-margin">Our Values.</h3>
                <p>Water supports health and promotes hydration without adding calories to the diet.
                    Sugary drinks including energy drinks, fruit drinks, 100% fruit juice, soft drinks and flavored coffees have lots of sugar and little to no nutritional value. It is easy to drink empty calories without realizing, and this leads to weight gain.
                    Avoid fruit juice, even when it is 100% fruit juice. Although fruit juice has some of the benefits of the fruit (vitamins, minerals), it has more sugar than the fruit and less fiber. Fruit juice should not be consumed as alternative to fruits. Canadians should eat their fruits, not drink them.</p>
            </div>

        </div>


    </div> <!-- end s-content__main -->

</div> <!-- end row -->

@endsection
