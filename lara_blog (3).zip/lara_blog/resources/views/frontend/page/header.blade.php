@php
$popular_post = DB::table('blog')
    ->orderBy('hit_count', 'asc')
    ->limit(1)
    ->get();
$popular_post2 = DB::table('blog')
    ->orderBy('hit_count', 'desc')
    ->limit(2)
    ->get();
@endphp
@extends('frontend/master')
@section('header')
    <div class="pageheader-content row">
        <div class="col-full">

            <div class="featured">

                <div class="featured__column featured__column--big">
                    @foreach ($popular_post as $row)
                    <div class="entry"
                        style="background-image:url('{{ asset($row->blog_image) }}');">

                            <div class="entry__content">
                                <span class="entry__category"><a href="{{ url('/blog_desc/'.$row->blog_id)}}">{{$row->category_name}}</a></span>

                                <h1><a href="#0" title="">{{$row->blog_name}}.</a></h1>

                                <div class="entry__info">
                                    <a href="#0" class="entry__profile-pic">
                                        <img class="avatar"
                                            src="{{ asset($row->blog_image) }}" alt="">
                                    </a>
                                    <ul class="entry__meta">
                                        <li><a href="#0">{{$row->author_name}}</a></li>
                                        <li>{{$row->created_at}}</li>
                                    </ul>
                                </div>
                            </div> <!-- end entry__content -->

                    </div> <!-- end entry -->
                    @endforeach
                </div> <!-- end featured__big -->

                <div class="featured__column featured__column--small">
                    @foreach ($popular_post2 as $row)


                    <div class="entry"
                        style="background-image:url('{{ asset($row->blog_image) }}');">

                        <div class="entry__content">
                            <span class="entry__category"><a href="{{ url('/blog_desc/'.$row->blog_id)}}">{{$row->category_name}}</a></span>

                            <h1><a href="#0" title="">{{$row->blog_name}}.</a></h1>

                            <div class="entry__info">
                                <a href="#0" class="entry__profile-pic">


                                    <img class="avatar" src="{{ asset($row->blog_image) }}"
                                        alt="">
                                </a>

                                <ul class="entry__meta">
                                    <li><a href="#0">{{$row->author_name}}</a></li>
                                    <li>{{$row->created_at}}</li>
                                </ul>
                            </div>
                        </div> <!-- end entry__content -->

                    </div> <!-- end entry -->
                    @endforeach


                </div> <!-- end featured__small -->
            </div> <!-- end featured -->

        </div> <!-- end col-full -->
    </div> <!-- end pageheader-content row -->

@endsection
