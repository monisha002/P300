<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;
class BackendController extends Controller
{
     public function index(){
     	return view('backend/login');
     }
     public function process_login(request $request)
     {
     	$this->validate($request,[
     		'name'     => 'required',
     		'password' => 'required|min:6'

     	]);

     	$name = $request->name;
     	$password = $request->password;

     	$result = DB::table('admin_login')
     				->where('name', $name)
     				->where('password', md5($password))
     				->first();

     	if ($result) {

     		// Session::put('name',$result->name);
     		// Session::put('id',$result->id);

     		// return Redirect::to('/dashboard');


     		$sidebar = view('backend/sidebar');
     		$dashboard = view('backend/dashboard');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$dashboard);
     	}
     	else
     	{
     		return Redirect::to('/admin');
     	}


     }
     public function logout()
     {
     	// Session::put('name','');
     	// 	Session::put('id','');
     		return Redirect::to('/admin');

     }
     public function category_form()
     {
     	    $sidebar = view('backend/sidebar');
     		$category_form = view('backend/category_form');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$category_form);
     }
     public function save_category(request $request)
     {
     	$this->validate($request,[
     		'category_name'     => 'required',
     		'category_desc' => 'required|min:5',
     		'p_status' => 'required',
     	]);

     	$data = array();
     	$data['category_name'] = $request->category_name; 
     	$data['category_description'] = $request->category_desc; 
     	$data['publication_status'] = $request->p_status;

     	DB::table('category')->insert($data);
     	Session::put('message','Category Saved Successfully !!');
     	return Redirect::to('CategoryForm'); 


     } 
     public function all_category()
     {
     		$all_category_data = DB::table('category')
     				             ->get();
     	  
     		$all_category = view('backend/all_category')
     						->with('all_category_data',$all_category_data);

     		$sidebar = view('backend/sidebar');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$all_category);
     }
     public function edit_category($category_id)
     {
     	$all_category = DB::table('category')
     							->where('category_id',$category_id)
     				             ->first();

     			$edit_category = view('backend/edit_category')
     						->with('all_category',$all_category);

     		$sidebar = view('backend/sidebar');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$edit_category);

     }
     public function update_category(request $request)
     {
     	

     	$data = array();
     	$data['category_name'] = $request->category_name; 
     	$data['category_description'] = $request->category_desc; 


     	$category_id = $request->category_id;

     	DB::table('category')
     	->where('category_id',$category_id)
     	->update($data);

     	
     	return Redirect::to('All-Category'); 
     }
     public function delete_category($category_id){
     	DB::table('category')
     	->where('category_id',$category_id)
     	->delete();

     	
     	return Redirect::to('All-Category'); 
     }



    public function add_blog_form()
    {

    		$all_category_data = DB::table('category')
     				             ->get();


     	    $sidebar = view('backend/sidebar');
     		$add_blog_form = view('backend/add_blog_form')
     							->with('all_category',$all_category_data);


     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$add_blog_form);
    }
    
     public function save_blog_post(request $request)
     {

   
     	$this->validate($request,[
     		'blog_name'     => 'required',
     		'category_name' => 'required',
     		'blog_short_description' => 'required',
     		'blog_long_description' => 'required',
     		'blog_image' => 'required',
     		'author_name' => 'required',
     		'publication_status' => 'required',
     	]);


        // $data['database table name'] = $request->from input field name;
     	$data = array();
     	$data['blog_name'] = $request->blog_name; 
     	$data['category_name'] = $request->category_name; 
     	$data['blog_short_description'] = $request->blog_short_description;
     	$data['blog_long_description'] = $request->blog_long_description;
     	$data['author_name'] = $request->author_name;
     	$data['hit_count'] = $request->hit_count = 0;

     	$data['publication_status'] = $request->publication_status;

     	// image upload

     	$files = $request->file('blog_image');
     	$filename = $files->getClientOriginalName();

     	$picture = date('His').$filename;
     	$image_url = 'public/post_image/'.$picture;

     	$destination_path = base_path().'/public/post_image/';
     	$success = $files->move($destination_path,$picture);

     	if ($success) {

     		$data['blog_image'] = $image_url;
     		DB::table('blog')->insert($data);
     	    Session::put('message','slider Saved Successfully !!');
     	    return Redirect::to('Add-Blog'); 
     	}
     	else{

     		$error = $files->getErrorMessage();


     	}
     	//end image upload

     


     }
     public function all_blog_post()
     {
     		$all_blog_post = DB::table('blog')
     				             ->get();
     	  
     		$all_blog_post = view('backend/all_blog_post')
     						->with('all_blog_post',$all_blog_post);

     		$sidebar = view('backend/sidebar');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$all_blog_post);
     }

  
}
