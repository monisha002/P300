<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Session;

class SuperadminController extends Controller
{
   
    public function index()
    {
        Session::put('name');
     		Session::put('id');
       	$sidebar = view('backend/sidebar');
     		$dashboard = view('backend/dashboard');
     		return view('backend/back_master')->with('sidebar',$sidebar)
                                              ->with('dashboard',$dashboard);
    }

    
}
