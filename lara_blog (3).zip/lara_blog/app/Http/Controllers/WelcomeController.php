<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;
use DB;
use Session;

class WelcomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $all_post = DB::table('blog')
                            ->get();


        $home = view('frontend/page/home_page')
                            ->with('all_post',$all_post);
        $header = view('frontend/page/header');
        return view('frontend/master')->with('main_contant',$home)
                                      ->with('header',$header);

    }

    public function contact()
    {
        $contact = view('frontend/page/contact_page');
        return view('frontend/master')->with('main_contant',$contact);
    }
    public function about()
    {
        $about = view('frontend/page/about');
        return view('frontend/master')->with('main_contant',$about);
    }
    public function category_post($category_name)
    {
        $category_post = DB::table('blog')
                                ->where('category_name',$category_name)
                                 ->get();


        $home = view('frontend/page/category_post_home_page')
                            ->with('category_post',$category_post);

        $header = view('frontend/page/header');
        return view('frontend/master')->with('main_contant',$home);




    }
    public function blog_desc($blog_id)
    {





        $post_desc = DB::table('blog')
                                ->where('blog_id',$blog_id)
                                 ->first();

         $data['hit_count'] = $post_desc->hit_count+1;

         DB::table('blog')
        ->where('blog_id',$blog_id)
        ->update($data);

        $home = view('frontend/page/post_desc')
                            ->with('post_desc',$post_desc);

        $header = view('frontend/page/header');
        return view('frontend/master')->with('main_contant',$home);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
