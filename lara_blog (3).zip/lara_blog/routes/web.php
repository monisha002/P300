<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'welcomecontroller@index')->name('home');
Route::get('/contact', 'welcomecontroller@contact')->name('contact');
Route::get('/about', 'welcomecontroller@about');
Route::get('/admin', 'backendcontroller@index');
Route::post('/dashboard','backendcontroller@process_login')->name('process_login');
Route::get('/logout', 'backendcontroller@index')->name('logout');

// Route::get('/ss','superadmincontroller@index');

Route::get('/CategoryForm', 'backendcontroller@category_form')->name('cat_form');
Route::post('/Save_Category', 'backendcontroller@save_category')->name('save_category');
Route::get('/All-Category', 'backendcontroller@all_category')->name('all_category');
Route::get('/edit_category/{id}', 'backendcontroller@edit_category');
Route::post('/Update_Category', 'backendcontroller@update_category')->name('update_category');
Route::get('/delete_category/{id}', 'backendcontroller@delete_category');


Route::get('/Add-Blog', 'backendcontroller@add_blog_form')->name('blog_form');
Route::post('/save_blog_post', 'backendcontroller@save_blog_post')->name('save_blog_post');
Route::get('/All-Blog', 'backendcontroller@all_blog_post')->name('all_blog_post');


Route::get('/category_blog/{name}', 'welcomecontroller@category_post');
Route::get('/blog_desc/{id}', 'welcomecontroller@blog_desc');

// Route::get('/dashboard','superadmincontroller@index');

